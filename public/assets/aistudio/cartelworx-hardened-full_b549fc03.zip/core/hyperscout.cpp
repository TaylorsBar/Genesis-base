// Hyperscout placeholder
