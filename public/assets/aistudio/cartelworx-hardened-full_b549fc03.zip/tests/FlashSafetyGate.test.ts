import { describe, it, expect, beforeEach, vi } from 'vitest';
import { FlashManager } from '../services/FlashManager';
import { IFlashTransport } from '../services/FlashTransport';
import { FlashSafetyGate, FlashSafetyInput } from '../services/FlashSafetyGate';
import { FlashSafetyAuditLog } from '../services/FlashSafetyAuditLog';
import { SecurityManager, UnknownSecurityAlgorithmError } from '../services/SecurityManager';

/**
 * Covers the audit's headline finding (§0): SafetyLayer/TuningValidator
 * existed and worked, but nothing on the actual flash-execution path ever
 * called them. These tests prove the gate is now structurally mandatory —
 * not just that the gate function itself works in isolation (that's
 * FlashSafetyGate's own logic, ported faithfully from
 * backend/app/services/physics.py's already-tested validate_tuning), but
 * that FlashManager.orchestrateFlash() actually calls it, and does so
 * BEFORE any hardware interaction, exactly like
 * test_flash_manager_rejects_unsafe_tune_and_writes_audit_log does on the
 * Python side for its own (unused) pipeline.
 */

class MockTransport implements IFlashTransport {
    public connectCalled = false;
    public transmitCalled = false;
    private receiveCallCount = 0;

    async connect(): Promise<boolean> {
        this.connectCalled = true;
        return true;
    }
    disconnect(): void {}
    async transmit(_payload: Uint8Array): Promise<boolean> {
        this.transmitCalled = true;
        return true;
    }
    async receive(): Promise<Uint8Array | null> {
        // orchestrateFlash's UDS 0x27 dance calls receive() twice: once for
        // the seed request (expects level echo 0x01), once for the key
        // verification (expects level echo 0x02). Echo the right level each
        // time rather than a single fixed response.
        this.receiveCallCount += 1;
        const level = this.receiveCallCount === 1 ? 0x01 : 0x02;
        return new Uint8Array([0x67, level, 0xAA, 0xBB]);
    }
}

const UNSAFE_TUNE: FlashSafetyInput = {
    ecuVariant: 'INFINITI_G25',
    ignition: {
        maxEgt: 999, // above the 950°C hard ceiling
        knockBuffer: 2.0,
    },
};

const SAFE_TUNE: FlashSafetyInput = {
    ecuVariant: 'INFINITI_G25',
    ignition: {
        maxEgt: 850,
        knockBuffer: 2.0,
        ignitionMap: [[10, 12, 14], [11, 13, 15]],
    },
};

beforeEach(() => {
    FlashSafetyAuditLog.clearLedger();
});

describe('FlashManager.orchestrateFlash — safety gate integration', () => {
    it('blocks an unsafe tune and never touches the transport at all', async () => {
        const transport = new MockTransport();
        const manager = new FlashManager(transport);
        const progressEvents: any[] = [];

        const result = await manager.orchestrateFlash(
            new Uint8Array([0xAA, 0xAA]),
            UNSAFE_TUNE,
            0x401,
            (p) => progressEvents.push(p)
        );

        expect(result).toBe(false);
        expect(transport.connectCalled).toBe(false); // <- the actual point of §0's fix
        expect(transport.transmitCalled).toBe(false);
        expect(progressEvents.some(p => p.stage.includes('Blocked by Safety Gate'))).toBe(true);
    });

    it('writes an audit-log entry for a rejected tune (approved AND denied must be logged)', async () => {
        const transport = new MockTransport();
        const manager = new FlashManager(transport);

        await manager.orchestrateFlash(new Uint8Array([0xAA]), UNSAFE_TUNE, 0x401, () => {});

        const ledger = FlashSafetyAuditLog.getLedger();
        expect(ledger.length).toBe(1);
        expect(ledger[0].approved).toBe(false);
        expect(ledger[0].status).toBe('REJECTED');

        const integrity = await FlashSafetyAuditLog.verifyChainIntegrity();
        expect(integrity.valid).toBe(true);
    });

    it('proceeds to hardware for a genuinely safe tune, and still logs the approval', async () => {
        const transport = new MockTransport();
        const manager = new FlashManager(transport);

        const result = await manager.orchestrateFlash(new Uint8Array([0xAA]), SAFE_TUNE, 0x401, () => {});

        expect(result).toBe(true);
        expect(transport.connectCalled).toBe(true);
        expect(transport.transmitCalled).toBe(true);

        const ledger = FlashSafetyAuditLog.getLedger();
        expect(ledger.length).toBe(1);
        expect(ledger[0].approved).toBe(true);
    });

    it('a malformed/adversarial tune config is rejected, not crashed, and still logged', async () => {
        const transport = new MockTransport();
        const manager = new FlashManager(transport);

        const garbage: any = { ignition: { maxEgt: 'not_a_number', knockBuffer: NaN } };
        const result = await manager.orchestrateFlash(new Uint8Array([0xAA]), garbage, 0x401, () => {});

        expect(result).toBe(false);
        expect(transport.connectCalled).toBe(false);
        expect(FlashSafetyAuditLog.getLedger().length).toBe(1);
    });
});

describe('FlashSafetyGate — fail-closed on malformed input (parity with physics.py)', () => {
    it.each([
        ['not_a_number'],
        [null],
        [NaN],
        [Infinity],
        [-Infinity],
        [[1, 2, 3]],
    ])('rejects maxEgt = %p instead of throwing', (badValue) => {
        const report = FlashSafetyGate.evaluate({ ignition: { maxEgt: badValue as any, knockBuffer: 2 } });
        expect(report.approved).toBe(false);
        expect(report.status).toBe('REJECTED');
    });

    it('never throws for any garbage top-level input', () => {
        const garbageInputs: any[] = [null, undefined, 'string', 42, [], () => {}, { ignition: 'nope' }];
        for (const g of garbageInputs) {
            expect(() => FlashSafetyGate.evaluate(g)).not.toThrow();
        }
    });

    it('still approves a genuinely valid tune (fail-closed must not become fail-open in reverse)', () => {
        const report = FlashSafetyGate.evaluate(SAFE_TUNE);
        expect(report.approved).toBe(true);
    });

    it('rejects a cell-to-cell ignition delta violation', () => {
        const report = FlashSafetyGate.evaluate({
            ignition: { maxEgt: 800, knockBuffer: 2, ignitionMap: [[10, 20]] }, // 10° delta > 5° max
        });
        expect(report.approved).toBe(false);
        expect(report.criticalViolations.some(v => v.includes('MAX_CELL_DELTA_VIOLATION'))).toBe(true);
    });
});

describe('SecurityManager.calculateKey — fail closed on unknown algorithm (frontend parity fix)', () => {
    it('throws instead of returning a fake zero key for an unrecognized algoId', () => {
        expect(() => SecurityManager.calculateKey(0x999, new Uint8Array([1, 2, 3, 4])))
            .toThrow(UnknownSecurityAlgorithmError);
    });

    it('still computes real keys for known algorithm IDs', () => {
        const key = SecurityManager.calculateKey(0x401, new Uint8Array([0x12, 0x34, 0x56, 0x78]));
        expect(key).toBeInstanceOf(Uint8Array);
        expect(key.length).toBeGreaterThan(0);
        // Not the old fail-open sentinel value.
        expect(Array.from(key)).not.toEqual([0x00, 0x00]);
    });
});
