import { describe, it, expect } from 'vitest';
import { TuningValidator } from '../services/TuningValidator';
import type { PlatformConfig } from '../types';

const config = { maxRpm: 7000 } as PlatformConfig;
const axis = [1000, 2000, 3000];

describe('TuningValidator.validateMap — fail-closed on non-finite cells', () => {
    it('rejects NaN instead of silently passing it (NaN > 55 and NaN < -30 are both false)', () => {
        const map = [[10, NaN, 20]];
        const result = TuningValidator.validateMap('ign', map, config, axis, [50]);
        expect(result.isValid).toBe(false);
        expect(result.errors.some(e => e.includes('MALFORMED_INPUT'))).toBe(true);
    });

    it('rejects Infinity the same way', () => {
        const map = [[10, Infinity, 20]];
        const result = TuningValidator.validateMap('boost', map, config, axis, [50]);
        expect(result.isValid).toBe(false);
        expect(result.errors.some(e => e.includes('MALFORMED_INPUT'))).toBe(true);
    });

    it('rejects a non-numeric cell (e.g. from a corrupted parse) instead of crashing', () => {
        const map = [['not_a_number' as any, 12, 14]];
        expect(() => TuningValidator.validateMap('ign', map, config, axis, [50])).not.toThrow();
        const result = TuningValidator.validateMap('ign', map, config, axis, [50]);
        expect(result.isValid).toBe(false);
    });

    it('still validates a genuinely clean map correctly', () => {
        const map = [[10, 12, 14]];
        const result = TuningValidator.validateMap('ign', map, config, axis, [50]);
        expect(result.isValid).toBe(true);
        expect(result.errors.length).toBe(0);
    });

    it('still catches real out-of-bounds violations, not just malformed ones', () => {
        const map = [[60, 12, 14]]; // 60 > 55 max ignition advance
        const result = TuningValidator.validateMap('ign', map, config, axis, [50]);
        expect(result.isValid).toBe(false);
        expect(result.errors.some(e => e.includes('Extreme advance'))).toBe(true);
    });
});
