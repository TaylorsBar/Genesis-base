"""
Property-based / fuzz testing for PhysicsKernel.validate_tuning(), per
PRODUCTION_HARDENING_BRIEF.md Phase 1:
    "Extend test coverage beyond the 7 ported cases with property-based/
    fuzz testing (e.g. hypothesis in Python) against adversarial and
    malformed configs."

The core invariant under test: validate_tuning() must NEVER raise. It must
always return (bool, report), for literally any input — because a raised
exception skips the caller's audit-log write in flash_manager.py, which
means a malformed/adversarial submission leaves no trace in the append-only
audit trail. That's the bug this file exists to keep fixed.
"""
import math
import pytest
from hypothesis import given, strategies as st, settings, HealthCheck

from app.services.physics import PhysicsKernel


kernel = PhysicsKernel()


# A JSON-like value strategy: the kind of thing a client could plausibly send
# as a "number" in a tune config, including the things a bare float() call
# would mishandle.
adversarial_scalar = st.one_of(
    st.floats(allow_nan=True, allow_infinity=True),
    st.integers(),
    st.text(max_size=20),
    st.none(),
    st.booleans(),
    st.lists(st.floats(), max_size=3),
    st.dictionaries(st.text(max_size=5), st.floats(), max_size=2),
)

tune_config_strategy = st.fixed_dictionaries(
    {},
    optional={
        "max_egt": adversarial_scalar,
        "max_egt_limit": adversarial_scalar,
        "knock_buffer": adversarial_scalar,
        "trial_timing": adversarial_scalar,
        "safe_knock_ceiling": adversarial_scalar,
        "ecu_variant": st.one_of(st.text(max_size=10), st.none()),
        "ignition_map": st.one_of(
            st.lists(st.lists(adversarial_scalar, max_size=3), max_size=3),
            adversarial_scalar,  # wrong type entirely
        ),
        "baseline_ignition_map": st.one_of(
            st.lists(st.lists(adversarial_scalar, max_size=3), max_size=3),
            adversarial_scalar,
        ),
    },
)


@settings(max_examples=300, suppress_health_check=[HealthCheck.too_slow])
@given(tune_config=tune_config_strategy)
def test_validate_tuning_never_raises(tune_config):
    """The headline property: no input shape crashes the gate."""
    is_valid, report = kernel.validate_tuning(tune_config)
    assert isinstance(is_valid, bool)
    assert report["status"] in ("PASSED", "PASSED_WITH_ADVISORIES", "REJECTED")
    # A crash-turned-rejection must still be legible to whoever reads the log.
    if not is_valid:
        assert isinstance(report.get("critical_violations"), list)
        assert len(report["critical_violations"]) > 0


@given(st.one_of(st.text(), st.integers(), st.floats(), st.none(), st.lists(st.integers())))
def test_validate_tuning_never_raises_on_non_dict_input(garbage):
    """Top-level input that isn't even a dict must also reject, not crash."""
    is_valid, report = kernel.validate_tuning(garbage)
    assert is_valid is False
    assert report["status"] == "REJECTED"


# --- Regression tests for the two specific bugs found in the audit ---

@pytest.mark.parametrize("bad_value", [
    "not_a_number", None, "NaN", float("nan"), float("inf"), float("-inf"), [1, 2, 3], {"x": 1},
])
def test_malformed_max_egt_is_rejected_not_crashed(bad_value):
    is_valid, report = kernel.validate_tuning({"max_egt": bad_value, "knock_buffer": 2.0})
    assert is_valid is False
    assert report["status"] == "REJECTED"
    assert any("MALFORMED_INPUT" in v for v in report["critical_violations"])


def test_nan_egt_is_rejected_not_silently_passed():
    """Regression test: NaN used to sail through as PASSED because every
    comparison against NaN is False, so it tripped neither the hard-ceiling
    nor the advisory-zone check."""
    is_valid, report = kernel.validate_tuning({"max_egt": float("nan"), "knock_buffer": 2.0})
    assert is_valid is False
    assert report["status"] == "REJECTED"


def test_infinity_egt_is_rejected():
    is_valid, report = kernel.validate_tuning({"max_egt": float("inf"), "knock_buffer": 2.0})
    assert is_valid is False
    assert report["status"] == "REJECTED"


def test_malformed_ignition_map_cell_is_rejected_not_crashed():
    is_valid, report = kernel.validate_tuning({
        "max_egt": 800.0,
        "knock_buffer": 2.0,
        "ignition_map": [[10.0, "bad", 14.0]],
    })
    assert is_valid is False
    assert report["status"] == "REJECTED"


def test_none_in_ignition_map_is_rejected_not_crashed():
    is_valid, report = kernel.validate_tuning({
        "max_egt": 800.0,
        "knock_buffer": 2.0,
        "ignition_map": [[10.0, None]],
    })
    assert is_valid is False
    assert report["status"] == "REJECTED"


def test_still_correctly_approves_a_genuinely_valid_tune():
    """Fail-closed fixes are only useful if they don't also fail OPEN by
    accident in the other direction — make sure a clean tune still passes."""
    is_valid, report = kernel.validate_tuning({
        "max_egt": 850.0,
        "knock_buffer": 2.0,
        "ignition_map": [[10.0, 12.0, 14.0], [11.0, 13.0, 15.0]],
    })
    assert is_valid is True
    assert report["status"] in ("PASSED", "PASSED_WITH_ADVISORIES")
