import os
import sys
from pathlib import Path

# Defensive fallback for pytest versions/setups that don't honor pytest.ini's
# `pythonpath` setting — makes `import app...` resolve regardless.
_BACKEND_ROOT = Path(__file__).resolve().parent.parent
if str(_BACKEND_ROOT) not in sys.path:
    sys.path.insert(0, str(_BACKEND_ROOT))

# app.main now refuses to start with no FLASH_SECRET_KEY configured (fail
# closed — see main.py). That's the right behavior in production; for the
# test suite we supply an explicit, obviously-fake, test-only value so the
# suite can run without a real secret and without weakening the production
# check itself. Real deployments must set a real FLASH_SECRET_KEY — this
# value is never used outside pytest.
os.environ.setdefault("FLASH_SECRET_KEY", "pytest-only-fake-secret-do-not-use-in-prod")
