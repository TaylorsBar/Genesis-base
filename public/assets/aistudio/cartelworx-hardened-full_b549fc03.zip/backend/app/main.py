import os
from fastapi import FastAPI, WebSocket, BackgroundTasks
from pydantic import BaseModel
from .services.flash_manager import FlashManager
from .services.integrity import SecurityError
from .api.websocket import bridge

app = FastAPI()

# Secret key MUST come from the environment — never hardcode this. A hardcoded
# key in source is a key that ships to every clone of this repo, including any
# public one; rotating it after the fact doesn't undo that exposure.
_secret_key = os.environ.get("FLASH_SECRET_KEY")
if not _secret_key:
    raise SecurityError(
        "FLASH_SECRET_KEY is not set. Refusing to start the flash API with no "
        "secret configured (fail closed). Set it in the environment before "
        "starting this service — see backend/.env.example."
    )

# J2534 is not the production hardware path (see HARDWARE_VALIDATION_PENDING.md —
# ELM327/Web Bluetooth is the chosen path) and connect() below is still an
# unimplemented stub. This wiring is kept only so the descoped path fails
# loudly and explicitly if something tries to use it, rather than silently
# pointing at a Windows path that doesn't exist on whatever host runs this API.
_j2534_dll_path = os.environ.get("J2534_DLL_PATH")  # intentionally None by default

manager = FlashManager(secret_key=_secret_key, dll_path=_j2534_dll_path)

class FlashRequest(BaseModel):
    config: dict
    binary: str

@app.post("/flash/initiate")
async def initiate_flash(payload: FlashRequest, background_tasks: BackgroundTasks):
    """
    Endpoint called by the React UI. 
    Runs the flash in a background task to avoid blocking the API.
    """
    
    async def run_pipeline():
        try:
            # This is the 'Glue' function that updates the WebSocket
            async def ui_update(progress, status):
                await bridge.broadcast_progress(progress, status)

            # Convert binary string to bytes (assuming base64 or similar in real app)
            binary_bytes = payload.binary.encode('utf-8')

            await manager.execute_flash_workflow(
                tune_config=payload.config, 
                binary_payload=binary_bytes, 
                ui_callback=ui_update
            )
        except Exception as e:
            await bridge.broadcast_error(str(e))

    background_tasks.add_task(run_pipeline)
    return {"status": "Pipeline Initiated", "job_id": "flash_001"}

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await bridge.connect(websocket)
    try:
        while True:
            data = await websocket.receive_text()
    except Exception:
        bridge.disconnect(websocket)
