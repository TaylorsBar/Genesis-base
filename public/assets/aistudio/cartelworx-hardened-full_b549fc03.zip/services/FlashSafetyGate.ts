/**
 * FlashSafetyGate
 *
 * The single mandatory pre-flight check before ANY bytes go to an ECU
 * through FlashManager.orchestrateFlash(). This is the fix for the audit's
 * headline finding: SafetyLayer.enforceConstraints() and
 * TuningValidator.validateMap() both existed and both worked, but neither
 * sat on the actual flash-execution path — a click on "Flash" never called
 * either one. This class is now called from inside FlashManager itself
 * (not just from a UI screen), so nothing can reach hardware without
 * passing through it, the same way backend/app/services/physics.py's
 * PhysicsKernel.validate_tuning() gates flash_manager.py on the Python side.
 *
 * Contract: evaluate() NEVER throws. Any internal error is caught and
 * converted into a REJECTED report — a crash here must never be
 * indistinguishable from "no gate ran at all" (see the fail-closed fix in
 * physics.py for the same reasoning, applied here to the pipeline that
 * actually runs).
 */

import { SafetyLayer } from './ATEngine';
import { TuningValidator } from './TuningValidator';
import { FlashSafetyAuditLog } from './FlashSafetyAuditLog';
import type { TuningTableType, PlatformConfig } from '../types';

export interface IgnitionSafetyConfig {
    maxEgt: number;
    maxEgtLimit?: number;
    knockBuffer?: number;
    trialTiming?: number;
    safeKnockCeiling?: number;
    ignitionMap?: number[][];
    baselineIgnitionMap?: number[][];
}

export interface TableSafetyInput {
    type: TuningTableType;
    map: number[][];
    xAxis: number[];
    yAxis: number[];
    platformConfig: PlatformConfig;
}

export interface FlashSafetyInput {
    ecuVariant?: string;
    ignition?: IgnitionSafetyConfig;
    tables?: TableSafetyInput[];
}

export interface FlashSafetyReport {
    approved: boolean;
    status: 'PASSED' | 'PASSED_WITH_ADVISORIES' | 'REJECTED';
    criticalViolations: string[];
    advisories: string[];
}

export class FlashSafetyRejectedError extends Error {
    constructor(public readonly report: FlashSafetyReport) {
        super(`Flash blocked by safety gate: ${report.criticalViolations.join('; ') || 'validation failed'}`);
        this.name = 'FlashSafetyRejectedError';
    }
}

function safeFinite(value: unknown, label: string, violations: string[]): number | null {
    if (typeof value !== 'number' && typeof value !== 'string') {
        violations.push(`Malformed field '${label}': ${JSON.stringify(value)} is not a valid number (MALFORMED_INPUT)`);
        return null;
    }
    const n = typeof value === 'number' ? value : Number(value);
    if (!Number.isFinite(n)) {
        violations.push(`Malformed field '${label}': ${JSON.stringify(value)} is not a finite number (MALFORMED_INPUT)`);
        return null;
    }
    return n;
}

function checkIgnitionMapDeltas(map: unknown, label: string, violations: string[]): void {
    if (!Array.isArray(map)) {
        violations.push(`Malformed field '${label}': must be a 2D array (MALFORMED_INPUT)`);
        return;
    }
    const rows = map.length;
    for (let r = 0; r < rows; r++) {
        const row = map[r];
        if (!Array.isArray(row)) {
            violations.push(`Malformed row in '${label}' at index ${r} (MALFORMED_INPUT)`);
            continue;
        }
        const cols = row.length;
        for (let c = 0; c < cols; c++) {
            const val = safeFinite(row[c], `${label}[${r}][${c}]`, violations);
            if (val === null) continue;
            if (c + 1 < cols) {
                const right = safeFinite(row[c + 1], `${label}[${r}][${c + 1}]`, violations);
                if (right !== null && Math.abs(val - right) > SafetyLayer.MAX_CELL_DELTA) {
                    violations.push(
                        `Cell delta violation at row ${r}, col ${c}->${c + 1}: ${Math.abs(val - right).toFixed(2)}° exceeds ${SafetyLayer.MAX_CELL_DELTA}° limit (MAX_CELL_DELTA_VIOLATION)`
                    );
                }
            }
            if (r + 1 < rows && Array.isArray(map[r + 1]) && c < map[r + 1].length) {
                const below = safeFinite(map[r + 1][c], `${label}[${r + 1}][${c}]`, violations);
                if (below !== null && Math.abs(val - below) > SafetyLayer.MAX_CELL_DELTA) {
                    violations.push(
                        `Cell delta violation at row ${r}->${r + 1}, col ${c}: ${Math.abs(val - below).toFixed(2)}° exceeds ${SafetyLayer.MAX_CELL_DELTA}° limit (MAX_CELL_DELTA_VIOLATION)`
                    );
                }
            }
        }
    }
}

export class FlashSafetyGate {
    /**
     * Evaluate a full tune/flash payload. Never throws — always returns a
     * report. Does NOT log; call recordAndEvaluate() from an async context
     * (e.g. FlashManager) to get the audit-logged version.
     */
    public static evaluate(input: FlashSafetyInput): FlashSafetyReport {
        const criticalViolations: string[] = [];
        const advisories: string[] = [];

        try {
            if (!input || typeof input !== 'object') {
                return { approved: false, status: 'REJECTED', criticalViolations: ['Malformed input: gate input must be an object'], advisories: [] };
            }

            const ign = input.ignition;
            if (ign) {
                const maxEgtLimit = safeFinite(ign.maxEgtLimit ?? SafetyLayer.MAX_EGT, 'ignition.maxEgtLimit', criticalViolations) ?? SafetyLayer.MAX_EGT;
                const maxEgt = safeFinite(ign.maxEgt, 'ignition.maxEgt', criticalViolations);

                if (maxEgt !== null) {
                    if (maxEgt > maxEgtLimit) {
                        criticalViolations.push(`Hard EGT limit violated: ${maxEgt}°C exceeds maximum threshold of ${maxEgtLimit}°C (EGT_HARD_CEILING)`);
                    } else if (maxEgt > SafetyLayer.ADVISORY_EGT) {
                        advisories.push(`EGT warning: Predicted EGT (${maxEgt}°C) enters advisory zone (> ${SafetyLayer.ADVISORY_EGT}°C) (EGT_ADVISORY_ZONE)`);
                    }
                }

                if (ign.knockBuffer !== undefined) {
                    const kb = safeFinite(ign.knockBuffer, 'ignition.knockBuffer', criticalViolations);
                    if (kb !== null && kb < SafetyLayer.KNOCK_BUFFER) {
                        criticalViolations.push(`Knock buffer violation: ${kb}° is below minimum safety margin of ${SafetyLayer.KNOCK_BUFFER}° (KNOCK_BUFFER_VIOLATION)`);
                    }
                }

                if (ign.trialTiming !== undefined && ign.safeKnockCeiling !== undefined) {
                    const trialTiming = safeFinite(ign.trialTiming, 'ignition.trialTiming', criticalViolations);
                    const safeCeiling = safeFinite(ign.safeKnockCeiling, 'ignition.safeKnockCeiling', criticalViolations);
                    if (trialTiming !== null && safeCeiling !== null && trialTiming >= safeCeiling - SafetyLayer.KNOCK_BUFFER) {
                        criticalViolations.push(
                            `Knock buffer violation: Trial timing (${trialTiming}°) exceeds safe ceiling minus buffer (${(safeCeiling - SafetyLayer.KNOCK_BUFFER).toFixed(2)}°) (KNOCK_BUFFER_VIOLATION)`
                        );
                    }
                }

                if (ign.ignitionMap !== undefined) {
                    checkIgnitionMapDeltas(ign.ignitionMap, 'ignitionMap', criticalViolations);

                    if (ign.baselineIgnitionMap !== undefined && Array.isArray(ign.ignitionMap) && Array.isArray(ign.baselineIgnitionMap)) {
                        const rows = Math.min(ign.ignitionMap.length, ign.baselineIgnitionMap.length);
                        for (let r = 0; r < rows; r++) {
                            const rowIgn = ign.ignitionMap[r];
                            const rowBase = ign.baselineIgnitionMap[r];
                            if (!Array.isArray(rowIgn) || !Array.isArray(rowBase)) continue;
                            const cols = Math.min(rowIgn.length, rowBase.length);
                            for (let c = 0; c < cols; c++) {
                                const a = safeFinite(rowIgn[c], `ignitionMap[${r}][${c}]`, criticalViolations);
                                const b = safeFinite(rowBase[c], `baselineIgnitionMap[${r}][${c}]`, criticalViolations);
                                if (a !== null && b !== null && Math.abs(a - b) > SafetyLayer.MAX_CELL_DELTA) {
                                    criticalViolations.push(
                                        `Cell delta from baseline violation at row ${r}, col ${c}: ${Math.abs(a - b).toFixed(2)}° exceeds ${SafetyLayer.MAX_CELL_DELTA}° limit (MAX_CELL_DELTA_VIOLATION)`
                                    );
                                }
                            }
                        }
                    }
                }
            }

            if (input.tables) {
                for (const table of input.tables) {
                    if (!table || !Array.isArray(table.map)) {
                        criticalViolations.push(`Malformed table entry (missing map) (MALFORMED_INPUT)`);
                        continue;
                    }
                    const result = TuningValidator.validateMap(table.type, table.map, table.platformConfig, table.xAxis, table.yAxis);
                    criticalViolations.push(...result.errors);
                    advisories.push(...result.warnings);
                }
            }
        } catch (e: any) {
            // Fail closed: whatever went wrong, this is a REJECTED tune, not
            // a pass-through. A thrown exception here must never be allowed
            // to look like "the gate approved this" to a caller.
            criticalViolations.push(`Internal safety-gate error treated as rejection: ${e?.message ?? String(e)} (MALFORMED_INPUT)`);
        }

        const approved = criticalViolations.length === 0;
        const status: FlashSafetyReport['status'] = !approved ? 'REJECTED' : (advisories.length > 0 ? 'PASSED_WITH_ADVISORIES' : 'PASSED');

        return { approved, status, criticalViolations, advisories };
    }

    /**
     * evaluate() + write an append-only, tamper-evident audit entry for the
     * decision (approved AND denied) — call this from FlashManager, not
     * evaluate() directly, so every real gate decision is on the record.
     */
    public static async recordAndEvaluate(input: FlashSafetyInput): Promise<FlashSafetyReport> {
        const report = this.evaluate(input);
        await FlashSafetyAuditLog.record({
            approved: report.approved,
            status: report.status,
            ecuVariant: input?.ecuVariant,
            rawInput: input,
            criticalViolations: report.criticalViolations,
            advisories: report.advisories,
        });
        return report;
    }

    /** Convenience for call sites that want a throw-on-reject shape. */
    public static async assertApproved(input: FlashSafetyInput): Promise<FlashSafetyReport> {
        const report = await this.recordAndEvaluate(input);
        if (!report.approved) {
            throw new FlashSafetyRejectedError(report);
        }
        return report;
    }
}
