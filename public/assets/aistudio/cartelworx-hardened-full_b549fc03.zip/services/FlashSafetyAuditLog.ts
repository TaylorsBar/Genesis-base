/**
 * FlashSafetyAuditLog
 *
 * Append-only, tamper-evident record of every FlashSafetyGate decision —
 * approved AND denied — mirroring backend/app/services/flash_manager.py's
 * log_flash_audit_event() on the Python side, for the pipeline that's
 * actually live (FlashManager.ts / PatchManager.ts).
 *
 * Uses the same SHA-256 hash-chaining approach as BlockchainLogger.ts
 * (each entry links to the previous entry's hash; mutating history breaks
 * verification), kept as its own ledger rather than shoehorned into
 * BlockchainLogger's AuditBlock schema — that schema's fields (vin,
 * sha256Hash-of-calibration, tunerId) represent a *confirmed* calibration
 * event. Forcing a REJECTED safety decision through it would misrepresent
 * a blocked flash as a confirmed one.
 *
 * Known limitation (tracked, not hidden): like BlockchainLogger, this is an
 * in-memory ledger. It does not yet survive a page reload / app restart.
 * Persisting it (e.g. via IndexedDB) is priority work before this can serve
 * as a real dispute/warranty record — see the audit report.
 */

export interface FlashSafetyAuditEntry {
    index: number;
    timestamp: number;
    eventType: 'FLASH_SAFETY_GATE';
    approved: boolean;
    status: 'PASSED' | 'PASSED_WITH_ADVISORIES' | 'REJECTED';
    ecuVariant?: string;
    inputHash: string; // SHA-256 of the JSON-stringified gate input, for reference/dispute matching without duplicating raw tune data in the log
    criticalViolations: string[];
    advisories: string[];
    previousHash: string;
    entryHash: string;
}

async function sha256Hex(input: string): Promise<string> {
    const encoder = new TextEncoder();
    const data = encoder.encode(input);
    if (typeof crypto !== 'undefined' && crypto.subtle) {
        const hashBuffer = await crypto.subtle.digest('SHA-256', data);
        return Array.from(new Uint8Array(hashBuffer)).map(b => b.toString(16).padStart(2, '0')).join('');
    }
    // Fallback for non-browser/crypto-subtle environments (matches
    // BlockchainLogger.ts's fallback). Weaker, but the log stays functional.
    let hash = 0;
    for (let i = 0; i < data.length; i++) {
        hash = (hash << 5) - hash + data[i];
        hash |= 0;
    }
    return Math.abs(hash).toString(16).padStart(64, '0');
}

export class FlashSafetyAuditLog {
    private static ledger: FlashSafetyAuditEntry[] = [];
    private static readonly GENESIS_PREVIOUS_HASH = '0'.repeat(64);

    public static async record(params: {
        approved: boolean;
        status: FlashSafetyAuditEntry['status'];
        ecuVariant?: string;
        rawInput: unknown;
        criticalViolations: string[];
        advisories: string[];
    }): Promise<FlashSafetyAuditEntry> {
        const index = this.ledger.length;
        const timestamp = Date.now();
        const previousHash = index === 0 ? this.GENESIS_PREVIOUS_HASH : this.ledger[index - 1].entryHash;
        const inputHash = await sha256Hex(JSON.stringify(params.rawInput ?? null));

        const payload = [
            index,
            timestamp,
            params.approved,
            params.status,
            params.ecuVariant ?? '',
            inputHash,
            params.criticalViolations.join('|'),
            params.advisories.join('|'),
            previousHash,
        ].join('::');
        const entryHash = await sha256Hex(payload);

        const entry: FlashSafetyAuditEntry = {
            index,
            timestamp,
            eventType: 'FLASH_SAFETY_GATE',
            approved: params.approved,
            status: params.status,
            ecuVariant: params.ecuVariant,
            inputHash,
            criticalViolations: params.criticalViolations,
            advisories: params.advisories,
            previousHash,
            entryHash,
        };

        this.ledger.push(entry);
        return entry;
    }

    public static async verifyChainIntegrity(): Promise<{ valid: boolean; corruptedIndex?: number }> {
        for (let i = 0; i < this.ledger.length; i++) {
            const entry = this.ledger[i];
            const expectedPrevious = i === 0 ? this.GENESIS_PREVIOUS_HASH : this.ledger[i - 1].entryHash;
            if (entry.previousHash !== expectedPrevious) {
                return { valid: false, corruptedIndex: i };
            }
            const payload = [
                entry.index,
                entry.timestamp,
                entry.approved,
                entry.status,
                entry.ecuVariant ?? '',
                entry.inputHash,
                entry.criticalViolations.join('|'),
                entry.advisories.join('|'),
                entry.previousHash,
            ].join('::');
            const expectedHash = await sha256Hex(payload);
            if (entry.entryHash !== expectedHash) {
                return { valid: false, corruptedIndex: i };
            }
        }
        return { valid: true };
    }

    public static getLedger(): FlashSafetyAuditEntry[] {
        return [...this.ledger];
    }

    /** For unit testing only. */
    public static clearLedger(): void {
        this.ledger = [];
    }
}
