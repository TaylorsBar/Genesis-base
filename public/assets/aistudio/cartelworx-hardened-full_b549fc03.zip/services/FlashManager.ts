import { SecurityManager } from "./SecurityManager";
import { calculateCRC32, prepareChunkedData } from "./FlashUtils";
import { IFlashTransport } from "./FlashTransport";
import { IsoTpLayer } from "./IsoTpLayer";
import { J2534Driver } from "./J2534Driver";
import { FlashSafetyGate, FlashSafetyInput, FlashSafetyReport } from "./FlashSafetyGate";

/**
 * FlashManager
 * 
 * Orchestrates the full ECU flash workflow:
 * 1. Diagnostic Session Management (UDS 0x10)
 * 2. Security Access Negotiation (UDS 0x27) via SecurityManager
 * 3. Memory Preparation & Download Request (UDS 0x34)
 * 4. Data Fragmentation & Transfer (UDS 0x36) via IsoTpLayer
 * 5. Completion & Integrity Verification (UDS 0x37 / 0x31)
 */

export interface FlashProgress {
    stage: string;
    progress: number;
    complete: boolean;
    error?: string;
    details?: string;
}

export class FlashManager {
    private transport: IFlashTransport;
    private security: SecurityManager;

    constructor(transport?: IFlashTransport) {
        // Default to J2534 for backward compatibility if no transport provided
        this.transport = transport || new IsoTpLayer(new J2534Driver());
        this.security = new SecurityManager();
    }

    /**
     * Executes the standard UDS Flashing Sequence.
     *
     * `safety` is required and is checked BEFORE anything touches hardware —
     * this is the fix for the gap where SafetyLayer/TuningValidator existed
     * and worked but were never on the actual flash path. See
     * FlashSafetyGate.ts for the full rationale. Passing an empty object
     * (`{}`) is allowed (e.g. for a region with no ignition/table data to
     * check) and will simply pass with no violations — but it can no longer
     * be skipped entirely, so a future caller can't silently bypass it the
     * way pages/FlashTuning.tsx used to.
     */
    public async orchestrateFlash(
        binaryData: Uint8Array,
        safety: FlashSafetyInput,
        algoId: number = 0x401, // Default to Bosch ME9 for VQ37
        onProgress: (p: FlashProgress) => void
    ): Promise<boolean> {
        // STEP -1: Safety gate. Runs and is logged before anything else —
        // including before the hardware interface is even initialized —
        // so a rejected tune never reaches the transport at all.
        onProgress({ stage: "Running pre-flight safety validation...", progress: 1, complete: false });
        let safetyReport: FlashSafetyReport;
        try {
            safetyReport = await FlashSafetyGate.recordAndEvaluate(safety);
        } catch (gateError: any) {
            // recordAndEvaluate()/evaluate() are designed to never throw, but
            // if audit logging itself fails, that still must not be treated
            // as approval.
            onProgress({
                stage: "Safety Gate Error — Flash Blocked",
                progress: 0,
                complete: false,
                error: `Safety gate could not be evaluated, so the flash is blocked: ${gateError?.message ?? String(gateError)}`,
            });
            return false;
        }

        if (!safetyReport.approved) {
            const reason = safetyReport.criticalViolations.join('; ') || 'Safety validation failed';
            onProgress({
                stage: "Flash Blocked by Safety Gate",
                progress: 0,
                complete: false,
                error: reason,
            });
            return false;
        }

        if (safetyReport.advisories.length > 0) {
            onProgress({
                stage: `Advisory: ${safetyReport.advisories.join('; ')}`,
                progress: 2,
                complete: false,
            });
        }

        try {
            // 0. Initialize Interface
            onProgress({ stage: "Initializing Hardware Interface...", progress: 5, complete: false });
            const connected = await this.transport.connect();
            if (!connected) throw new Error("Hardware interface connection failed.");

            // 1. Enter Extended Diagnostic Session (Service 0x10 0x03)
            onProgress({ stage: "Entering Extended Session (UDS 0x10 03)...", progress: 10, complete: false });
            await this.sendUdsRequest(new Uint8Array([0x10, 0x03]));
            await this.delay(500);

            // 2. Security Access (Service 0x27)
            onProgress({ stage: "Unlocking Secure Access (UDS 0x27)...", progress: 20, complete: false });
            const seed = await this.requestSeed(0x01);
            onProgress({ stage: "Calculating Security Key...", progress: 25, complete: false });
            const key = SecurityManager.calculateKey(algoId, seed);
            await this.sendKey(0x02, key);
            await this.delay(500);

            // 3. Request Download (Service 0x34)
            onProgress({ stage: "Requesting Download (UDS 0x34)...", progress: 35, complete: false });
            // Format: [0x34][DataFormatIdentifier][AddressAndLengthFormatIdentifier][MemoryAddress(4)][MemorySize(4)]
            const addr = 0x80000;
            const size = binaryData.length;
            const reqDownload = new Uint8Array([
                0x34, 0x00, 0x44, 
                (addr >> 24) & 0xFF, (addr >> 16) & 0xFF, (addr >> 8) & 0xFF, addr & 0xFF,
                (size >> 24) & 0xFF, (size >> 16) & 0xFF, (size >> 8) & 0xFF, size & 0xFF
            ]);
            await this.sendUdsRequest(reqDownload);
            await this.delay(800);

            // 4. Data Transfer (Service 0x36)
            onProgress({ stage: "Starting Binary Transfer...", progress: 40, complete: false });
            const chunks = prepareChunkedData(binaryData, 512); // Optimized block size
            for (let i = 0; i < chunks.length; i++) {
                const chunkPct = 40 + (i / chunks.length) * 50;
                onProgress({ 
                    stage: `Transferring Block ${i + 1}/${chunks.length}...`, 
                    progress: chunkPct, 
                    complete: false,
                    details: `${((i+1) * 512 / 1024).toFixed(1)} KB sent`
                });
                
                const transferData = new Uint8Array(chunks[i].length + 2);
                transferData[0] = 0x36;
                transferData[1] = (i + 1) % 256;
                transferData.set(chunks[i], 2);
                
                await this.sendUdsRequest(transferData);
                
                // Emulate inter-frame delay or flow control
                await this.delay(10);
            }

            // 5. Request Transfer Exit (Service 0x37)
            onProgress({ stage: "Closing Transfer Buffer (UDS 0x37)...", progress: 90, complete: false });
            await this.sendUdsRequest(new Uint8Array([0x37]));
            await this.delay(500);

            // 6. Integrity & Checksum Verification (Service 0x31)
            onProgress({ stage: "Verifying Integrity Checksum...", progress: 95, complete: false });
            const crc = calculateCRC32(binaryData);
            const verifyCmd = new Uint8Array([
                0x31, 0x01, 0xFF, 0x01, 
                (crc >> 24) & 0xFF, (crc >> 16) & 0xFF, (crc >> 8) & 0xFF, crc & 0xFF
            ]);
            await this.sendUdsRequest(verifyCmd);
            await this.delay(1000);

            onProgress({ stage: "ECU Flash Sequence Complete.", progress: 100, complete: true });
            return true;

        } catch (error: any) {
            console.error("[FLASH_MANAGER] Fatal Error:", error);
            onProgress({ 
                stage: "Flash Sequence Interrupted", 
                progress: 0, 
                complete: false, 
                error: error.message || "Unknown hardware fault" 
            });
            return false;
        } finally {
            this.transport.disconnect();
        }
    }

    /**
     * Internal helper to send payload securely via ISO-TP with flow control.
     */
    private async sendUdsRequest(payload: Uint8Array): Promise<void> {
        const success = await this.transport.transmit(payload);
        if (!success) {
            throw new Error("ISO-TP transmission failed (Flow Control abort/timeout)");
        }
    }

    /**
     * Request UDS Security Access Seed (Service 0x27).
     */
    private async requestSeed(level: number): Promise<Uint8Array> {
        // Send 27 [level]
        await this.sendUdsRequest(new Uint8Array([0x27, level]));
        
        // Read response (Service 0x67 is success)
        const response = await this.transport.receive();
        if (!response || response[0] !== 0x67 || response[1] !== level) {
            throw new Error(`Security Access Seed request failed. Response: ${response ? response.toString() : "timeout"}`);
        }
        
        // Return only the seed (bytes 2 onwards)
        return response.slice(2);
    }

    /**
     * Send UDS Security Access Key (Service 0x27).
     */
    private async sendKey(level: number, key: Uint8Array): Promise<void> {
        const payload = new Uint8Array(key.length + 2);
        payload[0] = 0x27;
        payload[1] = level;
        payload.set(key, 2);
        
        await this.sendUdsRequest(payload);
        
        // Verify response (Service 0x67 success)
        const response = await this.transport.receive();
        if (!response || response[0] !== 0x67 || response[1] !== level) {
            throw new Error(`Security Access Key verification failed. Response: ${response ? response.toString() : "timeout"}`);
        }
    }

    private delay(ms: number): Promise<void> {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}
